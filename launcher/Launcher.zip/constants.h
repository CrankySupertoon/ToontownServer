#include <QString>

const QString VERSION = "1.1.0";
const QString DISTRIBUTION = "test";
const QString USER_AGENT = "TTI-Launcher/1.1.0 (test/win32)";
const QString MANIFEST_FILENAME = "patcher.xml";

 QString URL_DOWNLOAD_MIRROR = "http://github.com/hackerofdarkness/Toontown_Server";
 QString GAME_SERVER = "";

 QString USERNAME = "";
 QString PANDAPATH = "";

 QString GAME_MODE = "";

 QString PPYTHON_PATH = PANDAPATH + "";
 QString TTS_PLAYCOOKIE = "";

 QString START = "C:/Users/thequ/Downloads/ToontownStride-master/ToontownStride-master/toontown/toonbase/ToontownStart.py";

